(() => {
var exports = {};
exports.id = 427;
exports.ids = [427];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 9309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'admin',
        {
        children: [
        'dashboard',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67737)), "/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/app/admin/dashboard/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82279)), "/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/app/admin/dashboard/page.tsx"];

    

    const originalPathname = "/admin/dashboard/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/admin/dashboard/page","pathname":"/admin/dashboard","bundlePath":"app/admin/dashboard/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 91655:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 73380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25621));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5574));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22452));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64784));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76264));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98803));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86499))

/***/ }),

/***/ 86499:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  DashboardTable: () => (/* binding */ DashboardTable),
  columns: () => (/* binding */ columns)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-table/build/lib/index.mjs
var lib = __webpack_require__(11200);
// EXTERNAL MODULE: ./node_modules/@tanstack/table-core/build/lib/index.mjs
var build_lib = __webpack_require__(75629);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(29256);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-checkbox/dist/index.mjs
var dist = __webpack_require__(68856);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/check.mjs
var check = __webpack_require__(27195);
// EXTERNAL MODULE: ./src/lib/utils.ts
var utils = __webpack_require__(12019);
;// CONCATENATED MODULE: ./src/components/ui/checkbox.tsx
/* __next_internal_client_entry_do_not_use__ Checkbox auto */ 




const Checkbox = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Root */.fC, {
        ref: ref,
        className: (0,utils.cn)("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* Indicator */.z$, {
            className: (0,utils.cn)("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ jsx_runtime_.jsx(check/* default */.Z, {
                className: "h-4 w-4"
            })
        })
    }));
Checkbox.displayName = dist/* Root */.fC.displayName;


// EXTERNAL MODULE: ./src/components/ui/dropdown-menu.tsx
var dropdown_menu = __webpack_require__(64784);
// EXTERNAL MODULE: ./src/components/ui/input.tsx
var input = __webpack_require__(17367);
;// CONCATENATED MODULE: ./src/components/ui/table.tsx



const Table = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full overflow-auto",
        children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
            ref: ref,
            className: (0,utils.cn)("w-full caption-bottom text-sm", className),
            ...props
        })
    }));
Table.displayName = "Table";
const TableHeader = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("thead", {
        ref: ref,
        className: (0,utils.cn)("[&_tr]:border-b", className),
        ...props
    }));
TableHeader.displayName = "TableHeader";
const TableBody = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("tbody", {
        ref: ref,
        className: (0,utils.cn)("[&_tr:last-child]:border-0", className),
        ...props
    }));
TableBody.displayName = "TableBody";
const TableFooter = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("tfoot", {
        ref: ref,
        className: (0,utils.cn)("bg-primary font-medium text-primary-foreground", className),
        ...props
    }));
TableFooter.displayName = "TableFooter";
const TableRow = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("tr", {
        ref: ref,
        className: (0,utils.cn)("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
        ...props
    }));
TableRow.displayName = "TableRow";
const TableHead = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("th", {
        ref: ref,
        className: (0,utils.cn)("h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0", className),
        ...props
    }));
TableHead.displayName = "TableHead";
const TableCell = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("td", {
        ref: ref,
        className: (0,utils.cn)("p-4 align-middle [&:has([role=checkbox])]:pr-0", className),
        ...props
    }));
TableCell.displayName = "TableCell";
const TableCaption = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("caption", {
        ref: ref,
        className: (0,utils.cn)("mt-4 text-sm text-muted-foreground", className),
        ...props
    }));
TableCaption.displayName = "TableCaption";


;// CONCATENATED MODULE: ./src/components/dashboard/components/dashboardTable.tsx
/* __next_internal_client_entry_do_not_use__ columns,DashboardTable auto */ 








const data = [
    {
        id: "m5gr84i9",
        tracking: "AWB0009690986",
        date: "2023-07-26	",
        destination: "United States-Los Angeles",
        amount: 316,
        status: "delivered",
        email: "ken99@yahoo.com"
    },
    {
        id: "3u1reuv4",
        tracking: "AWB0009690986",
        date: "2023-07-26	",
        destination: "United States-Los Angeles",
        amount: 242,
        status: "delivered",
        email: "Abe45@gmail.com"
    },
    {
        id: "derv1ws0",
        tracking: "AWB0009690986",
        date: "2023-07-26	",
        destination: "United States-Los Angeles",
        amount: 837,
        status: "processing",
        email: "Monserrat44@gmail.com"
    },
    {
        id: "5kma53ae",
        tracking: "AWB0009690986",
        date: "2023-07-26	",
        destination: "United States-Los Angeles",
        amount: 874,
        status: "delivered",
        email: "Silas22@gmail.com"
    },
    {
        id: "bhqecj4p",
        tracking: "AWB0009690986",
        date: "2023-07-26	",
        destination: "United States-Los Angeles",
        amount: 721,
        status: "failed",
        email: "carmella@hotmail.com"
    }
];
const columns = [
    {
        id: "select",
        header: ({ table })=>/*#__PURE__*/ jsx_runtime_.jsx(Checkbox, {
                checked: table.getIsAllPageRowsSelected(),
                onCheckedChange: (value)=>table.toggleAllPageRowsSelected(!!value),
                "aria-label": "Select all"
            }),
        cell: ({ row })=>/*#__PURE__*/ jsx_runtime_.jsx(Checkbox, {
                checked: row.getIsSelected(),
                onCheckedChange: (value)=>row.toggleSelected(!!value),
                "aria-label": "Select row"
            }),
        enableSorting: false,
        enableHiding: false
    },
    {
        accessorKey: "tracking",
        header: "Tracking",
        cell: ({ row })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "capitalize",
                children: row.getValue("tracking")
            })
    },
    {
        accessorKey: "date",
        header: "Date",
        cell: ({ row })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "capitalize",
                children: row.getValue("date")
            })
    },
    {
        accessorKey: "destination",
        header: "Destination",
        cell: ({ row })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "capitalize",
                children: row.getValue("destination")
            })
    },
    {
        accessorKey: "email",
        header: ({ column })=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                variant: "ghost",
                onClick: ()=>column.toggleSorting(column.getIsSorted() === "asc"),
                children: [
                    "Email",
                    /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CaretSortIcon */.jnn, {
                        className: "ml-2 h-4 w-4"
                    })
                ]
            });
        }
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "capitalize",
                children: row.getValue("status")
            })
    },
    {
        accessorKey: "amount",
        header: ()=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-right",
                children: "Total cost"
            }),
        cell: ({ row })=>{
            const amount = parseFloat(row.getValue("amount"));
            // Format the amount as a dollar amount
            const formatted = new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD"
            }).format(amount);
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-right font-medium",
                children: formatted
            });
        }
    },
    {
        id: "actions",
        enableHiding: false,
        cell: ({ row })=>{
            const payment = row.original;
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu.DropdownMenu, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuTrigger, {
                        asChild: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                            variant: "ghost",
                            className: "h-8 w-8 p-0",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "sr-only",
                                    children: "Open menu"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* DotsHorizontalIcon */.nWS, {
                                    className: "h-4 w-4"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu.DropdownMenuContent, {
                        align: "end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuLabel, {
                                children: "Actions"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuItem, {
                                onClick: ()=>navigator.clipboard.writeText(payment.id),
                                children: "Copy payment ID"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuSeparator, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuItem, {
                                children: "View customer"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuItem, {
                                children: "View payment details"
                            })
                        ]
                    })
                ]
            });
        }
    }
];
function DashboardTable() {
    const [sorting, setSorting] = react_.useState([]);
    const [columnFilters, setColumnFilters] = react_.useState([]);
    const [columnVisibility, setColumnVisibility] = react_.useState({});
    const [rowSelection, setRowSelection] = react_.useState({});
    const table = (0,lib/* useReactTable */.b7)({
        data,
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: (0,build_lib/* getCoreRowModel */.sC)(),
        getPaginationRowModel: (0,build_lib/* getPaginationRowModel */.G_)(),
        getSortedRowModel: (0,build_lib/* getSortedRowModel */.tj)(),
        getFilteredRowModel: (0,build_lib/* getFilteredRowModel */.vL)(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center py-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                        placeholder: "Filter emails...",
                        value: (table.getColumn("email")?.getFilterValue()) ?? "",
                        onChange: (event)=>table.getColumn("email")?.setFilterValue(event.target.value),
                        className: "max-w-sm"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu.DropdownMenu, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuTrigger, {
                                asChild: true,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "outline",
                                    className: "ml-auto",
                                    children: [
                                        "Columns ",
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* ChevronDownIcon */.v4q, {
                                            className: "ml-2 h-4 w-4"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuContent, {
                                align: "end",
                                children: table.getAllColumns().filter((column)=>column.getCanHide()).map((column)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu.DropdownMenuCheckboxItem, {
                                        className: "capitalize",
                                        checked: column.getIsVisible(),
                                        onCheckedChange: (value)=>column.toggleVisibility(!!value),
                                        children: column.id
                                    }, column.id);
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "rounded-md border",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Table, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(TableHeader, {
                            children: table.getHeaderGroups().map((headerGroup)=>/*#__PURE__*/ jsx_runtime_.jsx(TableRow, {
                                    children: headerGroup.headers.map((header)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx(TableHead, {
                                            children: header.isPlaceholder ? null : (0,lib/* flexRender */.ie)(header.column.columnDef.header, header.getContext())
                                        }, header.id);
                                    })
                                }, headerGroup.id))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TableBody, {
                            children: table.getRowModel().rows?.length ? table.getRowModel().rows.map((row)=>/*#__PURE__*/ jsx_runtime_.jsx(TableRow, {
                                    "data-state": row.getIsSelected() && "selected",
                                    children: row.getVisibleCells().map((cell)=>/*#__PURE__*/ jsx_runtime_.jsx(TableCell, {
                                            children: (0,lib/* flexRender */.ie)(cell.column.columnDef.cell, cell.getContext())
                                        }, cell.id))
                                }, row.id)) : /*#__PURE__*/ jsx_runtime_.jsx(TableRow, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(TableCell, {
                                    colSpan: columns.length,
                                    className: "h-24 text-center",
                                    children: "No results."
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-end space-x-2 py-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex-1 text-sm text-muted-foreground",
                        children: [
                            table.getFilteredSelectedRowModel().rows.length,
                            " of",
                            " ",
                            table.getFilteredRowModel().rows.length,
                            " row(s) selected."
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "space-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>table.previousPage(),
                                disabled: !table.getCanPreviousPage(),
                                children: "Previous"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>table.nextPage(),
                                disabled: !table.getCanNextPage(),
                                children: "Next"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 76264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  CalendarDateRangePicker: () => (/* binding */ CalendarDateRangePicker)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
// EXTERNAL MODULE: ./node_modules/date-fns/esm/addDays/index.js
var addDays = __webpack_require__(73709);
// EXTERNAL MODULE: ./node_modules/date-fns/esm/format/index.js + 19 modules
var format = __webpack_require__(72351);
// EXTERNAL MODULE: ./src/lib/utils.ts
var utils = __webpack_require__(12019);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(29256);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-left.mjs
var chevron_left = __webpack_require__(39246);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-right.mjs
var chevron_right = __webpack_require__(94834);
// EXTERNAL MODULE: ./node_modules/react-day-picker/dist/index.js
var dist = __webpack_require__(28070);
;// CONCATENATED MODULE: ./src/components/ui/calendar.tsx
/* __next_internal_client_entry_do_not_use__ Calendar auto */ 





function Calendar({ className, classNames, showOutsideDays = true, ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* DayPicker */._W, {
        showOutsideDays: showOutsideDays,
        className: (0,utils.cn)("p-3", className),
        classNames: {
            months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
            month: "space-y-4",
            caption: "flex justify-center pt-1 relative items-center",
            caption_label: "text-sm font-medium",
            nav: "space-x-1 flex items-center",
            nav_button: (0,utils.cn)((0,ui_button/* buttonVariants */.d)({
                variant: "outline"
            }), "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"),
            nav_button_previous: "absolute left-1",
            nav_button_next: "absolute right-1",
            table: "w-full border-collapse space-y-1",
            head_row: "flex",
            head_cell: "text-muted-foreground rounded-md w-9 font-normal text-[0.8rem]",
            row: "flex w-full mt-2",
            cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
            day: (0,utils.cn)((0,ui_button/* buttonVariants */.d)({
                variant: "ghost"
            }), "h-9 w-9 p-0 font-normal aria-selected:opacity-100"),
            day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
            day_today: "bg-accent text-accent-foreground",
            day_outside: "text-muted-foreground opacity-50",
            day_disabled: "text-muted-foreground opacity-50",
            day_range_middle: "aria-selected:bg-accent aria-selected:text-accent-foreground",
            day_hidden: "invisible",
            ...classNames
        },
        components: {
            IconLeft: ({ ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(chevron_left/* default */.Z, {
                    className: "h-4 w-4"
                }),
            IconRight: ({ ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(chevron_right/* default */.Z, {
                    className: "h-4 w-4"
                })
        },
        ...props
    });
}
Calendar.displayName = "Calendar";


// EXTERNAL MODULE: ./src/components/ui/popover.tsx
var popover = __webpack_require__(2331);
;// CONCATENATED MODULE: ./src/components/dashboard/components/date-range-picker.tsx
/* __next_internal_client_entry_do_not_use__ CalendarDateRangePicker auto */ 








function CalendarDateRangePicker({ className }) {
    const [date, setDate] = react_.useState({
        from: new Date(2023, 0, 20),
        to: (0,addDays/* default */.Z)(new Date(2023, 0, 20), 20)
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("grid gap-2", className),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(popover/* Popover */.J2, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(popover/* PopoverTrigger */.xo, {
                    asChild: true,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                        id: "date",
                        variant: "outline",
                        className: (0,utils.cn)("w-[260px] justify-start text-left font-normal", !date && "text-muted-foreground"),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CalendarIcon */.Que, {
                                className: "mr-2 h-4 w-4"
                            }),
                            date?.from ? date.to ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    (0,format/* default */.Z)(date.from, "LLL dd, y"),
                                    " -",
                                    " ",
                                    (0,format/* default */.Z)(date.to, "LLL dd, y")
                                ]
                            }) : (0,format/* default */.Z)(date.from, "LLL dd, y") : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Pick a date"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(popover/* PopoverContent */.yk, {
                    className: "w-auto p-0",
                    align: "end",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Calendar, {
                        initialFocus: true,
                        mode: "range",
                        defaultMonth: date?.from,
                        selected: date,
                        onSelect: setDate,
                        numberOfMonths: 2
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 98803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Overview: () => (/* binding */ Overview)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48472);
/* __next_internal_client_entry_do_not_use__ Overview auto */ 

const data = [
    {
        name: "Jan",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Feb",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Mar",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Apr",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "May",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Jun",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Jul",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Aug",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Sep",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Oct",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Nov",
        total: Math.floor(Math.random() * 5000) + 1000
    },
    {
        name: "Dec",
        total: Math.floor(Math.random() * 5000) + 1000
    }
];
function Overview() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_1__/* .ResponsiveContainer */ .h2, {
        width: "100%",
        height: 350,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(recharts__WEBPACK_IMPORTED_MODULE_1__/* .BarChart */ .vz, {
            data: data,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_1__/* .XAxis */ .Kc, {
                    dataKey: "name",
                    stroke: "#888888",
                    fontSize: 12,
                    tickLine: false,
                    axisLine: false
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_1__/* .YAxis */ .B2, {
                    stroke: "#888888",
                    fontSize: 12,
                    tickLine: false,
                    axisLine: false,
                    tickFormatter: (value)=>`$${value}`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(recharts__WEBPACK_IMPORTED_MODULE_1__/* .Bar */ .$Q, {
                    dataKey: "total",
                    fill: "#adfa1d",
                    radius: [
                        4,
                        4,
                        0,
                        0
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 5574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TeamSwitcher)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(79130);
// EXTERNAL MODULE: ./src/lib/utils.ts
var utils = __webpack_require__(12019);
// EXTERNAL MODULE: ./src/components/ui/avatar.tsx
var avatar = __webpack_require__(22452);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(29256);
// EXTERNAL MODULE: ./node_modules/cmdk/dist/index.js
var dist = __webpack_require__(27754);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/search.mjs
var search = __webpack_require__(29769);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-dialog/dist/index.mjs
var react_dialog_dist = __webpack_require__(7589);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/x.mjs
var x = __webpack_require__(95833);
;// CONCATENATED MODULE: ./src/components/ui/dialog.tsx
/* __next_internal_client_entry_do_not_use__ Dialog,DialogTrigger,DialogContent,DialogHeader,DialogFooter,DialogTitle,DialogDescription auto */ 




const dialog_Dialog = react_dialog_dist/* Root */.fC;
const DialogTrigger = react_dialog_dist/* Trigger */.xz;
const DialogPortal = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(react_dialog_dist/* Portal */.h_, {
        className: (0,utils.cn)(className),
        ...props
    });
DialogPortal.displayName = react_dialog_dist/* Portal */.h_.displayName;
const DialogOverlay = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_dialog_dist/* Overlay */.aV, {
        ref: ref,
        className: (0,utils.cn)("fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props
    }));
DialogOverlay.displayName = react_dialog_dist/* Overlay */.aV.displayName;
const dialog_DialogContent = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogPortal, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DialogOverlay, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_dialog_dist/* Content */.VY, {
                ref: ref,
                className: (0,utils.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg md:w-full", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_dialog_dist/* Close */.x8, {
                        className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(x/* default */.Z, {
                                className: "h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "sr-only",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
dialog_DialogContent.displayName = react_dialog_dist/* Content */.VY.displayName;
const DialogHeader = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col space-y-1.5 text-center sm:text-left", className),
        ...props
    });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    });
DialogFooter.displayName = "DialogFooter";
const DialogTitle = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_dialog_dist/* Title */.Dx, {
        ref: ref,
        className: (0,utils.cn)("text-lg font-semibold leading-none tracking-tight", className),
        ...props
    }));
DialogTitle.displayName = react_dialog_dist/* Title */.Dx.displayName;
const DialogDescription = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_dialog_dist/* Description */.dk, {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
DialogDescription.displayName = react_dialog_dist/* Description */.dk.displayName;


;// CONCATENATED MODULE: ./src/components/ui/command.tsx
/* __next_internal_client_entry_do_not_use__ Command,CommandDialog,CommandInput,CommandList,CommandEmpty,CommandGroup,CommandItem,CommandShortcut,CommandSeparator auto */ 





const Command = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command, {
        ref: ref,
        className: (0,utils.cn)("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className),
        ...props
    }));
Command.displayName = dist.Command.displayName;
const CommandDialog = ({ children, ...props })=>{
    return /*#__PURE__*/ _jsx(Dialog, {
        ...props,
        children: /*#__PURE__*/ _jsx(DialogContent, {
            className: "overflow-hidden p-0 shadow-lg",
            children: /*#__PURE__*/ _jsx(Command, {
                className: "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5",
                children: children
            })
        })
    });
};
const CommandInput = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center border-b px-3",
        "cmdk-input-wrapper": "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(search/* default */.Z, {
                className: "mr-2 h-4 w-4 shrink-0 opacity-50"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dist.Command.Input, {
                ref: ref,
                className: (0,utils.cn)("flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
                ...props
            })
        ]
    }));
CommandInput.displayName = dist.Command.Input.displayName;
const CommandList = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command.List, {
        ref: ref,
        className: (0,utils.cn)("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
        ...props
    }));
CommandList.displayName = dist.Command.List.displayName;
const CommandEmpty = /*#__PURE__*/ react_.forwardRef((props, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command.Empty, {
        ref: ref,
        className: "py-6 text-center text-sm",
        ...props
    }));
CommandEmpty.displayName = dist.Command.Empty.displayName;
const CommandGroup = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command.Group, {
        ref: ref,
        className: (0,utils.cn)("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
        ...props
    }));
CommandGroup.displayName = dist.Command.Group.displayName;
const CommandSeparator = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command.Separator, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 h-px bg-border", className),
        ...props
    }));
CommandSeparator.displayName = dist.Command.Separator.displayName;
const CommandItem = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist.Command.Item, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-accent aria-selected:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props
    }));
CommandItem.displayName = dist.Command.Item.displayName;
const CommandShortcut = ({ className, ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: (0,utils.cn)("ml-auto text-xs tracking-widest text-muted-foreground", className),
        ...props
    });
};
CommandShortcut.displayName = "CommandShortcut";


// EXTERNAL MODULE: ./src/components/ui/input.tsx
var input = __webpack_require__(17367);
// EXTERNAL MODULE: ./src/components/ui/label.tsx
var label = __webpack_require__(89122);
// EXTERNAL MODULE: ./src/components/ui/popover.tsx
var popover = __webpack_require__(2331);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-select/dist/index.mjs + 2 modules
var react_select_dist = __webpack_require__(4917);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-down.mjs
var chevron_down = __webpack_require__(36595);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/check.mjs
var check = __webpack_require__(27195);
;// CONCATENATED MODULE: ./src/components/ui/select.tsx
/* __next_internal_client_entry_do_not_use__ Select,SelectGroup,SelectValue,SelectTrigger,SelectContent,SelectLabel,SelectItem,SelectSeparator auto */ 




const Select = react_select_dist/* Root */.fC;
const SelectGroup = react_select_dist/* Group */.ZA;
const SelectValue = react_select_dist/* Value */.B4;
const SelectTrigger = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_select_dist/* Trigger */.xz, {
        ref: ref,
        className: (0,utils.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Icon */.JO, {
                asChild: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx(chevron_down/* default */.Z, {
                    className: "h-4 w-4 opacity-50"
                })
            })
        ]
    }));
SelectTrigger.displayName = react_select_dist/* Trigger */.xz.displayName;
const SelectContent = /*#__PURE__*/ react_.forwardRef(({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Portal */.h_, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Content */.VY, {
            ref: ref,
            className: (0,utils.cn)("relative z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Viewport */.l_, {
                className: (0,utils.cn)("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                children: children
            })
        })
    }));
SelectContent.displayName = react_select_dist/* Content */.VY.displayName;
const SelectLabel = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Label */.__, {
        ref: ref,
        className: (0,utils.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }));
SelectLabel.displayName = react_select_dist/* Label */.__.displayName;
const SelectItem = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_select_dist/* Item */.ck, {
        ref: ref,
        className: (0,utils.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(check/* default */.Z, {
                        className: "h-4 w-4"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* ItemText */.eT, {
                children: children
            })
        ]
    }));
SelectItem.displayName = react_select_dist/* Item */.ck.displayName;
const SelectSeparator = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Separator */.Z0, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }));
SelectSeparator.displayName = react_select_dist/* Separator */.Z0.displayName;


;// CONCATENATED MODULE: ./src/components/dashboard/components/team-switcher.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











const groups = [
    {
        label: "Personal Account",
        teams: [
            {
                label: "Alicia Koch",
                value: "personal"
            }
        ]
    },
    {
        label: "Teams",
        teams: [
            {
                label: "Acme Inc.",
                value: "acme-inc"
            },
            {
                label: "Monsters Inc.",
                value: "monsters"
            }
        ]
    }
];
function TeamSwitcher({ className }) {
    const [open, setOpen] = react_.useState(false);
    const [showNewTeamDialog, setShowNewTeamDialog] = react_.useState(false);
    const [selectedTeam, setSelectedTeam] = react_.useState(groups[0].teams[0]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog_Dialog, {
        open: showNewTeamDialog,
        onOpenChange: setShowNewTeamDialog,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(popover/* Popover */.J2, {
                open: open,
                onOpenChange: setOpen,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(popover/* PopoverTrigger */.xo, {
                        asChild: true,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                            variant: "outline",
                            role: "combobox",
                            "aria-expanded": open,
                            "aria-label": "Select a team",
                            className: (0,utils.cn)("w-[200px] justify-between", className),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar.Avatar, {
                                    className: "mr-2 h-5 w-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarImage, {
                                            src: `https://avatar.vercel.sh/${selectedTeam.value}.png`,
                                            alt: selectedTeam.label
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarFallback, {
                                            children: "SC"
                                        })
                                    ]
                                }),
                                selectedTeam.label,
                                /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CaretSortIcon */.jnn, {
                                    className: "ml-auto h-4 w-4 shrink-0 opacity-50"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(popover/* PopoverContent */.yk, {
                        className: "w-[200px] p-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Command, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CommandList, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(CommandInput, {
                                            placeholder: "Search team..."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(CommandEmpty, {
                                            children: "No team found."
                                        }),
                                        groups.map((group)=>/*#__PURE__*/ jsx_runtime_.jsx(CommandGroup, {
                                                heading: group.label,
                                                children: group.teams.map((team)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(CommandItem, {
                                                        onSelect: ()=>{
                                                            setSelectedTeam(team);
                                                            setOpen(false);
                                                        },
                                                        className: "text-sm",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar.Avatar, {
                                                                className: "mr-2 h-5 w-5",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarImage, {
                                                                        src: `https://avatar.vercel.sh/${team.value}.png`,
                                                                        alt: team.label,
                                                                        className: "grayscale"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarFallback, {
                                                                        children: "SC"
                                                                    })
                                                                ]
                                                            }),
                                                            team.label,
                                                            /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* CheckIcon */.nQG, {
                                                                className: (0,utils.cn)("ml-auto h-4 w-4", selectedTeam.value === team.value ? "opacity-100" : "opacity-0")
                                                            })
                                                        ]
                                                    }, team.value))
                                            }, group.label))
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(CommandSeparator, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(CommandList, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CommandGroup, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DialogTrigger, {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CommandItem, {
                                                onSelect: ()=>{
                                                    setOpen(false);
                                                    setShowNewTeamDialog(true);
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* PlusCircledIcon */.SPS, {
                                                        className: "mr-2 h-5 w-5"
                                                    }),
                                                    "Create Team"
                                                ]
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog_DialogContent, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogHeader, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(DialogTitle, {
                                children: "Create team"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(DialogDescription, {
                                children: "Add a new team to manage products and customers."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-4 py-2 pb-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(label/* Label */._, {
                                            htmlFor: "name",
                                            children: "Team name"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                            id: "name",
                                            placeholder: "Acme Inc."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(label/* Label */._, {
                                            htmlFor: "plan",
                                            children: "Subscription plan"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Select, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(SelectTrigger, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(SelectValue, {
                                                        placeholder: "Select a plan"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(SelectContent, {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(SelectItem, {
                                                            value: "free",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "font-medium",
                                                                    children: "Free"
                                                                }),
                                                                " -",
                                                                " ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-muted-foreground",
                                                                    children: "Trial for two weeks"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(SelectItem, {
                                                            value: "pro",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "font-medium",
                                                                    children: "Pro"
                                                                }),
                                                                " -",
                                                                " ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-muted-foreground",
                                                                    children: "$9/month per user"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogFooter, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                variant: "outline",
                                onClick: ()=>setShowNewTeamDialog(false),
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                type: "submit",
                                children: "Continue"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 22452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Avatar: () => (/* binding */ Avatar),
/* harmony export */   AvatarFallback: () => (/* binding */ AvatarFallback),
/* harmony export */   AvatarImage: () => (/* binding */ AvatarImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2129);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12019);
/* __next_internal_client_entry_do_not_use__ Avatar,AvatarImage,AvatarFallback auto */ 



const Avatar = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Root */ .fC, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
        ...props
    }));
Avatar.displayName = _radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Root */ .fC.displayName;
const AvatarImage = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Image */ .Ee, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("aspect-square h-full w-full", className),
        ...props
    }));
AvatarImage.displayName = _radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Image */ .Ee.displayName;
const AvatarFallback = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Fallback */ .NY, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
        ...props
    }));
AvatarFallback.displayName = _radix_ui_react_avatar__WEBPACK_IMPORTED_MODULE_2__/* .Fallback */ .NY.displayName;



/***/ }),

/***/ 2331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J2: () => (/* binding */ Popover),
/* harmony export */   xo: () => (/* binding */ PopoverTrigger),
/* harmony export */   yk: () => (/* binding */ PopoverContent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12820);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12019);
/* __next_internal_client_entry_do_not_use__ Popover,PopoverTrigger,PopoverContent auto */ 



const Popover = _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__/* .Root */ .fC;
const PopoverTrigger = _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__/* .Trigger */ .xz;
const PopoverContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__/* .Portal */ .h_, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__/* .Content */ .VY, {
            ref: ref,
            align: align,
            sideOffset: sideOffset,
            className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
            ...props
        })
    }));
PopoverContent.displayName = _radix_ui_react_popover__WEBPACK_IMPORTED_MODULE_2__/* .Content */ .VY.displayName;



/***/ }),

/***/ 25621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Tabs: () => (/* binding */ Tabs),
/* harmony export */   TabsContent: () => (/* binding */ TabsContent),
/* harmony export */   TabsList: () => (/* binding */ TabsList),
/* harmony export */   TabsTrigger: () => (/* binding */ TabsTrigger)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1150);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12019);
/* __next_internal_client_entry_do_not_use__ Tabs,TabsList,TabsTrigger,TabsContent auto */ 



const Tabs = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .Root */ .fC;
const TabsList = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .List */ .aV, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }));
TabsList.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .List */ .aV.displayName;
const TabsTrigger = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .Trigger */ .xz, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }));
TabsTrigger.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .Trigger */ .xz.displayName;
const TabsContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .Content */ .VY, {
        ref: ref,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_3__.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }));
TabsContent.displayName = _radix_ui_react_tabs__WEBPACK_IMPORTED_MODULE_2__/* .Content */ .VY.displayName;



/***/ }),

/***/ 67737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MusicPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(14178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(45108);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./src/components/ui/tabs.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/ui/tabs.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Tabs"];

const e1 = proxy["TabsList"];

const e2 = proxy["TabsTrigger"];

const e3 = proxy["TabsContent"];

// EXTERNAL MODULE: ./src/lib/utils.ts
var utils = __webpack_require__(67669);
;// CONCATENATED MODULE: ./src/components/sidebar.tsx



function Sidebar({ className, playlists }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("pb-12", className),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "space-y-4 py-4",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-3 py-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-2 px-4 text-lg font-semibold tracking-tight",
                            children: "Discover"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "secondary",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "12",
                                                    r: "10"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                                    points: "10 8 16 12 10 16 10 8"
                                                })
                                            ]
                                        }),
                                        "Dashboard"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    width: "7",
                                                    height: "7",
                                                    x: "3",
                                                    y: "3",
                                                    rx: "1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    width: "7",
                                                    height: "7",
                                                    x: "14",
                                                    y: "3",
                                                    rx: "1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    width: "7",
                                                    height: "7",
                                                    x: "14",
                                                    y: "14",
                                                    rx: "1"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    width: "7",
                                                    height: "7",
                                                    x: "3",
                                                    y: "14",
                                                    rx: "1"
                                                })
                                            ]
                                        }),
                                        "Shipment"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M4.9 19.1C1 15.2 1 8.8 4.9 4.9"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "12",
                                                    r: "2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19.1 4.9C23 8.8 23 15.1 19.1 19"
                                                })
                                            ]
                                        }),
                                        "Customers"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M4.9 19.1C1 15.2 1 8.8 4.9 4.9"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "12",
                                                    r: "2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19.1 4.9C23 8.8 23 15.1 19.1 19"
                                                })
                                            ]
                                        }),
                                        "Contacts"
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-3 py-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-2 px-4 text-lg font-semibold tracking-tight",
                            children: "Manage Users"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M21 15V6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 12H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M16 6H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18H3"
                                                })
                                            ]
                                        }),
                                        "Users Control Panel"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "8",
                                                    cy: "18",
                                                    r: "4"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18V2l7 4"
                                                })
                                            ]
                                        }),
                                        "Create User"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "7",
                                                    r: "4"
                                                })
                                            ]
                                        }),
                                        "List of Users"
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-3 py-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-2 px-4 text-lg font-semibold tracking-tight",
                            children: "Shipment"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M21 15V6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 12H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M16 6H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18H3"
                                                })
                                            ]
                                        }),
                                        "Shipping Control Panel"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "8",
                                                    cy: "18",
                                                    r: "4"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18V2l7 4"
                                                })
                                            ]
                                        }),
                                        "Create Shipment"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "7",
                                                    r: "4"
                                                })
                                            ]
                                        }),
                                        "List of Shipment"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m12 8-9.04 9.06a2.82 2.82 0 1 0 3.98 3.98L16 12"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "17",
                                                    cy: "7",
                                                    r: "5"
                                                })
                                            ]
                                        }),
                                        "List of Payment"
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-3 py-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-2 px-4 text-lg font-semibold tracking-tight",
                            children: "Settings"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M21 15V6"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 12H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M16 6H3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18H3"
                                                })
                                            ]
                                        }),
                                        "Profile Stettings"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "8",
                                                    cy: "18",
                                                    r: "4"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M12 18V2l7 4"
                                                })
                                            ]
                                        }),
                                        "Payment Settings"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "12",
                                                    cy: "7",
                                                    r: "4"
                                                })
                                            ]
                                        }),
                                        "Site Settings"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                                    variant: "ghost",
                                    className: "w-full justify-start",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            className: "mr-2 h-4 w-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m12 8-9.04 9.06a2.82 2.82 0 1 0 3.98 3.98L16 12"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "17",
                                                    cy: "7",
                                                    r: "5"
                                                })
                                            ]
                                        }),
                                        "Users Settings"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/data/playlists.ts
const playlists = [
    "Recently Added",
    "Recently Played",
    "Top Songs",
    "Top Albums",
    "Top Artists",
    "Logic Discography",
    "Bedtime Beats",
    "Feeling Happy",
    "I miss Y2K Pop",
    "Runtober",
    "Mellow Days",
    "Eminem Essentials"
];

;// CONCATENATED MODULE: ./src/components/dashboard/components/team-switcher.tsx

const team_switcher_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/dashboard/components/team-switcher.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: team_switcher_esModule, $$typeof: team_switcher_$$typeof } = team_switcher_proxy;
const team_switcher_default_ = team_switcher_proxy.default;


/* harmony default export */ const team_switcher = (team_switcher_default_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(25124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/dashboard/components/main-nav.tsx



function MainNav({ className, ...props }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: (0,utils.cn)("flex items-center space-x-4 lg:space-x-6", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/dashboard",
                className: "text-sm font-medium transition-colors hover:text-primary",
                children: "Overview"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/customers",
                className: "text-sm font-medium text-muted-foreground transition-colors hover:text-primary",
                children: "Customers"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/examples/dashboard",
                className: "text-sm font-medium text-muted-foreground transition-colors hover:text-primary",
                children: "Products"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/products",
                className: "text-sm font-medium text-muted-foreground transition-colors hover:text-primary",
                children: "Settings"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(62947);
;// CONCATENATED MODULE: ./src/components/ui/input.tsx



const Input = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("input", {
        type: type,
        className: (0,utils.cn)("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    });
});
Input.displayName = "Input";


;// CONCATENATED MODULE: ./src/components/dashboard/components/search.tsx


function Search() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Input, {
            type: "search",
            placeholder: "Search...",
            className: "md:w-[100px] lg:w-[300px]"
        })
    });
}

;// CONCATENATED MODULE: ./src/components/ui/avatar.tsx

const avatar_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/ui/avatar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: avatar_esModule, $$typeof: avatar_$$typeof } = avatar_proxy;
const avatar_default_ = avatar_proxy.default;

const avatar_e0 = avatar_proxy["Avatar"];

const avatar_e1 = avatar_proxy["AvatarImage"];

const avatar_e2 = avatar_proxy["AvatarFallback"];

;// CONCATENATED MODULE: ./src/components/ui/dropdown-menu.tsx

const dropdown_menu_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/ui/dropdown-menu.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: dropdown_menu_esModule, $$typeof: dropdown_menu_$$typeof } = dropdown_menu_proxy;
const dropdown_menu_default_ = dropdown_menu_proxy.default;

const dropdown_menu_e0 = dropdown_menu_proxy["DropdownMenu"];

const dropdown_menu_e1 = dropdown_menu_proxy["DropdownMenuTrigger"];

const dropdown_menu_e2 = dropdown_menu_proxy["DropdownMenuContent"];

const dropdown_menu_e3 = dropdown_menu_proxy["DropdownMenuItem"];

const e4 = dropdown_menu_proxy["DropdownMenuCheckboxItem"];

const e5 = dropdown_menu_proxy["DropdownMenuRadioItem"];

const e6 = dropdown_menu_proxy["DropdownMenuLabel"];

const e7 = dropdown_menu_proxy["DropdownMenuSeparator"];

const e8 = dropdown_menu_proxy["DropdownMenuShortcut"];

const e9 = dropdown_menu_proxy["DropdownMenuGroup"];

const e10 = dropdown_menu_proxy["DropdownMenuPortal"];

const e11 = dropdown_menu_proxy["DropdownMenuSub"];

const e12 = dropdown_menu_proxy["DropdownMenuSubContent"];

const e13 = dropdown_menu_proxy["DropdownMenuSubTrigger"];

const e14 = dropdown_menu_proxy["DropdownMenuRadioGroup"];

;// CONCATENATED MODULE: ./src/components/dashboard/components/user-nav.tsx




function UserNav() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e0, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu_e1, {
                asChild: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                    variant: "ghost",
                    className: "relative h-8 w-8 rounded-full",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "h-8 w-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/01.png",
                                alt: "@shadcn"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "SC"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e2, {
                className: "w-56",
                align: "end",
                forceMount: true,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(e6, {
                        className: "font-normal",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col space-y-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm font-medium leading-none",
                                    children: "shadcn"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-xs leading-none text-muted-foreground",
                                    children: "m@example.com"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(e7, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e9, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e3, {
                                children: [
                                    "Profile",
                                    /*#__PURE__*/ jsx_runtime_.jsx(e8, {
                                        children: "⇧⌘P"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e3, {
                                children: [
                                    "Billing",
                                    /*#__PURE__*/ jsx_runtime_.jsx(e8, {
                                        children: "⌘B"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e3, {
                                children: [
                                    "Settings",
                                    /*#__PURE__*/ jsx_runtime_.jsx(e8, {
                                        children: "⌘S"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu_e3, {
                                children: "New Team"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(e7, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu_e3, {
                        children: [
                            "Log out",
                            /*#__PURE__*/ jsx_runtime_.jsx(e8, {
                                children: "⇧⌘Q"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/dashboard/components/date-range-picker.tsx

const date_range_picker_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/dashboard/components/date-range-picker.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: date_range_picker_esModule, $$typeof: date_range_picker_$$typeof } = date_range_picker_proxy;
const date_range_picker_default_ = date_range_picker_proxy.default;

const date_range_picker_e0 = date_range_picker_proxy["CalendarDateRangePicker"];

;// CONCATENATED MODULE: ./src/components/ui/card.tsx



const Card = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("h3", {
        ref: ref,
        className: (0,utils.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)(" flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";


;// CONCATENATED MODULE: ./src/components/dashboard/components/overview.tsx

const overview_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/dashboard/components/overview.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: overview_esModule, $$typeof: overview_$$typeof } = overview_proxy;
const overview_default_ = overview_proxy.default;

const overview_e0 = overview_proxy["Overview"];

;// CONCATENATED MODULE: ./src/components/dashboard/components/recent-sales.tsx


function RecentSales() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "space-y-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "h-9 w-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/01.png",
                                alt: "Avatar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "OM"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-4 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm font-medium leading-none",
                                children: "Olivia Martin"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-muted-foreground",
                                children: "olivia.martin@email.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-auto font-medium",
                        children: "+$1,999.00"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "flex h-9 w-9 items-center justify-center space-y-0 border",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/02.png",
                                alt: "Avatar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "JL"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-4 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm font-medium leading-none",
                                children: "Jackson Lee"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-muted-foreground",
                                children: "jackson.lee@email.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-auto font-medium",
                        children: "+$39.00"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "h-9 w-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/03.png",
                                alt: "Avatar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "IN"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-4 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm font-medium leading-none",
                                children: "Isabella Nguyen"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-muted-foreground",
                                children: "isabella.nguyen@email.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-auto font-medium",
                        children: "+$299.00"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "h-9 w-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/04.png",
                                alt: "Avatar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "WK"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-4 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm font-medium leading-none",
                                children: "William Kim"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-muted-foreground",
                                children: "will@email.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-auto font-medium",
                        children: "+$99.00"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar_e0, {
                        className: "h-9 w-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e1, {
                                src: "/avatars/05.png",
                                alt: "Avatar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(avatar_e2, {
                                children: "SD"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-4 space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm font-medium leading-none",
                                children: "Sofia Davis"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-muted-foreground",
                                children: "sofia.davis@email.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-auto font-medium",
                        children: "+$39.00"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/dashboard/components/dashboardTable.tsx

const dashboardTable_proxy = (0,module_proxy.createProxy)(String.raw`/home/isofttechn/MERNSTACK PROJECTS/PackPushers/frontend/src/components/dashboard/components/dashboardTable.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: dashboardTable_esModule, $$typeof: dashboardTable_$$typeof } = dashboardTable_proxy;
const dashboardTable_default_ = dashboardTable_proxy.default;

const dashboardTable_e0 = dashboardTable_proxy["columns"];

const dashboardTable_e1 = dashboardTable_proxy["DashboardTable"];

;// CONCATENATED MODULE: ./src/app/admin/dashboard/page.tsx


// import { PlusCircledIcon } from "@radix-ui/react-icons"

// import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"












// import "../../components/dashboard/components/dashboardStyle.css"
const metadata = {
    title: "PackPushers",
    description: "Track your packges"
};
function MusicPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/examples/music-light.png",
                        width: 1280,
                        height: 1114,
                        alt: "Music",
                        className: "block dark:hidden"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/examples/music-dark.png",
                        width: 1280,
                        height: 1114,
                        alt: "Music",
                        className: "hidden dark:block"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden md:block",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border-b",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex h-16 items-center px-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(team_switcher, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(MainNav, {
                                    className: "mx-6"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "ml-auto flex items-center space-x-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Search, {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(UserNav, {})
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-5 gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-span-1",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {
                                    playlists: playlists,
                                    className: "hidden lg:block"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-span-4 p-8 pt-6",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-3xl font-bold tracking-tight",
                                        children: "Dashboard"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-between space-x-2 mb-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(date_range_picker_e0, {}),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                                children: "Download"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                                        defaultValue: "overview",
                                        className: "space-y-4",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e3, {
                                            value: "overview",
                                            className: "space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "grid gap-4 md:grid-cols-2 lg:grid-cols-4",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardHeader, {
                                                                    className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                        className: "text-sm font-medium",
                                                                        children: "Total Revenue"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardContent, {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "text-2xl font-bold",
                                                                            children: "$45,231.89"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs text-muted-foreground",
                                                                            children: "+20.1% from last month"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardHeader, {
                                                                    className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                        className: "text-sm font-medium",
                                                                        children: "Subscriptions"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardContent, {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "text-2xl font-bold",
                                                                            children: "+2350"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs text-muted-foreground",
                                                                            children: "+180.1% from last month"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardHeader, {
                                                                    className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                        className: "text-sm font-medium",
                                                                        children: "Subscriptions"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardContent, {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "text-2xl font-bold",
                                                                            children: "+2350"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs text-muted-foreground",
                                                                            children: "+180.1% from last month"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardHeader, {
                                                                    className: "flex flex-row items-center justify-between space-y-0 pb-2",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                        className: "text-sm font-medium",
                                                                        children: "Subscriptions"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardContent, {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "text-2xl font-bold",
                                                                            children: "+2350"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs text-muted-foreground",
                                                                            children: "+180.1% from last month"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "grid gap-4 md:grid-cols-2 lg:grid-cols-7",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            className: "col-span-4",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardHeader, {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                        children: "Package Sale Graph"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardContent, {
                                                                    className: "pl-2",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(overview_e0, {})
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                                                            className: "col-span-3",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardHeader, {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                                            children: "Recent Sales"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx(CardDescription, {
                                                                            children: "You made 265 sales this month."
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CardContent, {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(RecentSales, {})
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(dashboardTable_e1, {})
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [697,327,618,328,24,230,690,108], () => (__webpack_exec__(9309)));
module.exports = __webpack_exports__;

})();